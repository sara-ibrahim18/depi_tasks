﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EF_CodefFirst.Migrations
{
    /// <inheritdoc />
    public partial class v4 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "JoinTime",
                table: "authors",
                newName: "JoinDate");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.RenameColumn(
                name: "JoinDate",
                table: "authors",
                newName: "JoinTime");
        }
    }
}
