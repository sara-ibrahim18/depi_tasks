﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace EF_CodefFirst.Migrations
{
    /// <inheritdoc />
    public partial class v7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "AuthorId",
                table: "newss",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CategoryId",
                table: "newss",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_newss_AuthorId",
                table: "newss",
                column: "AuthorId");

            migrationBuilder.CreateIndex(
                name: "IX_newss_CategoryId",
                table: "newss",
                column: "CategoryId");

            migrationBuilder.AddForeignKey(
                name: "FK_newss_authors_AuthorId",
                table: "newss",
                column: "AuthorId",
                principalTable: "authors",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_newss_categories_CategoryId",
                table: "newss",
                column: "CategoryId",
                principalTable: "categories",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_newss_authors_AuthorId",
                table: "newss");

            migrationBuilder.DropForeignKey(
                name: "FK_newss_categories_CategoryId",
                table: "newss");

            migrationBuilder.DropIndex(
                name: "IX_newss_AuthorId",
                table: "newss");

            migrationBuilder.DropIndex(
                name: "IX_newss_CategoryId",
                table: "newss");

            migrationBuilder.DropColumn(
                name: "AuthorId",
                table: "newss");

            migrationBuilder.DropColumn(
                name: "CategoryId",
                table: "newss");
        }
    }
}
